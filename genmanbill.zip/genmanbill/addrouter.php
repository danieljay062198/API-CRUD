<?php include_once('includes/headhtml.php'); ?>


  	<div class="card">
        <div class="card-header">
          <h3 class="card-title"><i class="fa fa-gear"></i> Router Settings &nbsp; | &nbsp;&nbsp;<i onclick="location.reload();" class="fa fa-refresh pointer " title="Reload data"></i></h3>
        </div>
        <div class="card-body">
          <div class="row">          
        
          </div>
        </div>
    </div>

<?php include_once('includes/footerhtml.php'); ?>