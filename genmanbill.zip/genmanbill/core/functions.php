<?php

function redirect_to($path){
	die("<meta http-equiv='refresh' content=0;URL='".$path."' />");
}

?>